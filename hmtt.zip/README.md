git add . 把代码从工作区添加到暂存区
git commit -m "提交说明" 把代码从暂存区提交到仓库
git push -u origin master(第一次这样写)
git push

1. 写一行看一下控制台 打印一行
2. ajax 看 network 载荷 如果是 404 一般是地址写错了
3. 多打印看代码执行到哪一行

找一种最好的方式 没有好的样式 效果有就行

flex 不行就上 postion:absolute;
margin 或 padding 挤一挤

1. 写一行看一行 console.log 一行
2. 尽量 CV
3. ajax 要看载荷 参数有没有传对 状态码

先静后动 先布局再考虑 js

哪些样式可以继承 color font 开头 line-开头
