import Vue from 'vue'
import CollectArticle from './CollectArticle.vue'
Vue.component(CollectArticle.name, CollectArticle)
