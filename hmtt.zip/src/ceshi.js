import Vue from 'vue'
Vue.filter('a', function () { })
Vue.filter('b', function () { })
